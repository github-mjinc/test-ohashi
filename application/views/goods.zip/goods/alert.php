<?php echo doctype("html5"); ?>
<html lang="ja">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>oohashi_test</title>
    <!-- BootstrapのCSS読み込み -->
    <link rel="stylesheet" href="<?php echo base_url()?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>css/style.css">
    <!-- jQuery読み込み -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- BootstrapのJS読み込み -->
    <script src="js/bootstrap.min.js"></script>
  </head>
<body>
  <div class="container">
    <?php echo br(1);
    echo heading('削除 内容確認', 1, 'class="delete"');
    echo br(1); ?>
    <p class="text_delete">こちらの内容を取り消してもよろしいでしょうか？</p>
    <p class="text_delete">よろしれば、「削除する」ボタンを押してください。 </p>
    <div class="border col-8">
      <?php echo br(1); ?>
      <table class="table table-striped">
        <thead class="thead-dark">
          <tr>
            <th>#</th>
            <th>タイトル</th>
            <th>内容</th>
            <th>在庫状態</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
              <td>ハリーポッターと賢者の石</td>
              <td>ファンタジー</td>
              <td>有り</td>
          </tr>
        </tbody>
      </table>
    </div>
    <?php echo br(2); ?>
    <div class="row center-block text-center">
      <div class="col-3">
        <?php echo anchor('goods/index', '<button type="button" class="btn btn-outline-secondary btn-block">削除</button>')?>
      </div>
      <div class="col-3">
        <?php echo anchor('goods/index', '<button type="button" class="btn btn-outline-primary btn-block">取り消す</button>')?>
      </div>
  </div>
  </div>
</body>
</html>