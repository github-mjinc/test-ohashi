<?php echo doctype("html5"); ?>
<html lang="ja">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>oohashi_test</title>
    <!-- BootstrapのCSS読み込み -->
    <link rel="stylesheet" href="<?php echo base_url()?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>css/style.css">
    <!-- jQuery読み込み -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- BootstrapのJS読み込み -->
    <script src="js/bootstrap.min.js"></script>
  </head>
  <body>
    <div class="container">
      <div class="table-responsive"></div>
        <table class="table table-striped">
          <thead class="thead-dark">
            <tr>
              <th>#</th>
              <th>タイトル</th>
              <th>内容</th>
              <th>在庫状態</th>
              <th>削除</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">1</th>
                <td>ハリーポッターと賢者の石</td>
                <td>ファンタジー</td>
                <td>有り</td>
                <td>
                  <?php echo anchor('goods/alert', '<button type="button" class="btn-primary btn-lg active">削除</button>')?>
                </td>
            </tr>
            <tr>
              <th scope="row">2</th>
                <td>ワイルド・スピード　スーパーコンボ</td>
                <td>アクション</td>
                <td>有り</td>
                <td>
                  <?php echo anchor('goods/alert', '<button type="button" class="btn-primary btn-lg active">削除</button>')?>
                </td>
            </tr>
            <tr>
              <th scope="row">3</th>
                <td>キングスマン　ゴールデンサークル</td>
                <td>SF</td>
                <td>有り</td>
                <td>
                  <?php echo anchor('goods/alert', '<button type="button" class="btn-primary btn-lg active">削除</button>')?>
                </td>
            </tr>
            <tr>
              <th scope="row">4</th>
                <td>ミッションインポッシブル　スカイミッション</td>
                <td>アクション</td>
                <td>有り</td>
                <td>
                  <?php echo anchor('goods/alert', '<button type="button" class="btn-primary btn-lg active">削除</button>')?>
                </td>
            </tr>
            <tr>
              <th scope="row">5</th>
                <td>トランスポーター</td>
                <td>アクション</td>
                <td>有り</td>
                <td>
                  <?php echo anchor('goods/alert', '<button type="button" class="btn-primary btn-lg active">削除</button>')?>
                </td>
            </tr>
          </tbody>
        </table>
        <?php echo anchor('goods/index', 'リストに戻る')?>
      </div>
    </body>
  </html>