<?php echo doctype("html5"); ?>
<html lang="ja">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>oohashi_test</title>
    <!-- BootstrapのCSS読み込み -->
    <link rel="stylesheet" href="<?php echo base_url()?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>css/style.css">
    <!-- jQuery読み込み -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- BootstrapのJS読み込み -->
    <script src="js/bootstrap.min.js"></script>
  </head>
  <body>
    <?php echo br(1);
    echo heading('データ登録', 1, 'class="title"');
    echo br(1); ?>
    <div class="border col-7">
    <?php echo br(1);
      echo heading('データ登録', 2 );
      echo br(1); ?>
      <div class="row">
        <div class="col-md">
          <?php echo form_open('form'); ?>
            <div class="form-group">
                <label>タイトル：</label>
                <input type="text" class="form-control" placeholder="title">
            </div>
            <div class="form-group">
                <label>内容：</label>
                <select class="form-control">
                    <option>アクション</option>
                    <option>アドベンチャー</option>
                    <option>アニメ</option>
                    <option>SF</option>
                    <option>音楽</option>
                    <option>コメディ</option>
                    <option>サスペンス</option>
                    <option>スポーツ</option>
                    <option>ドラマ</option>
                    <option>ホラー</option>
                    <option>ミステリー</option>
                    <option>ミュージカル</option>
                    <option>恋愛</option>
                </select>
            </div>
            <div class="form-group">
              <label>在庫：</label>
              <select class="form-control">
                  <option>有</option>
                  <option>無</option>
              </select>
            </div>
              <div class="form-group">
                  <label>補足：</label>
                  <textarea class="form-control" rows="3"></textarea>
              </div>
              </form>
            </div>
        </div>
        <div class="row center-block text-center">
          <div class="col-1">
          </div>
          <div class="col-5">
            <?php echo anchor('goods/index', '<button type="button" class="btn btn-outline-secondary btn-block">閉じる</button>')?>
          </div>
          <div class="col-5">
            <?php echo anchor('goods/index', '<button type="button" class="btn btn-outline-primary btn-block">登録する</button>')?> 
            <?php echo br(1); ?>
          </div>
        </div>
  </body>
 
</html>