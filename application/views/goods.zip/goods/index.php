<?php echo doctype("html5"); ?>
<html lang="ja">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>oohashi_test</title>
    <!-- BootstrapのCSS読み込み -->
    <link rel="stylesheet" href="<?php echo base_url()?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>css/style.css">
    <!-- jQuery読み込み -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- BootstrapのJS読み込み -->
    <script src="js/bootstrap.min.js"></script>
  </head>
  <body>
    <div class="container">
      <table class="table table-striped">
        <thead class="thead-dark">
          <tr>
            <th>#</th>
            <th>タイトル</th>
            <th>内容</th>
            <th>在庫状態</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
              <td>ハリーポッターと賢者の石</td>
              <td>ファンタジー</td>
              <td>有り</td>
          </tr>
          <tr>
            <th scope="row">2</th>
              <td>ワイルド・スピード　スーパーコンボ</td>
              <td>アクション</td>
              <td>有り</td>
          </tr>
          <tr>
            <th scope="row">3</th>
              <td>キングスマン　ゴールデンサークル</td>
              <td>SF</td>
              <td>有り</td>
          </tr>
          <tr>
            <th scope="row">4</th>
              <td>ミッションインポッシブル　スカイミッション</td>
              <td>アクション</td>
              <td>有り</td>
          </tr>
          <tr>
            <th scope="row">5</th>
              <td>トランスポーター</td>
              <td>アクション</td>
              <td>有り</td>
          </tr>
        </tbody>
      </table>
        <div class="row center-block text-center">
          <div class="col-1">
          </div>
          <div class="col-5">
            <?php echo anchor('goods/delete', '<button type="button" class="btn btn-outline-secondary btn-block">削除</button>')?>
          </div>
          <div class="col-5">
            <?php echo anchor('goods/edit', '<button type="button" class="btn btn-outline-primary btn-block">新規登録</button>')?> 
          </div>
      </div>
      </div>
    </body>
  </html>